package com.digitalbook.entity;

/**
 * 
 * @author sindhu
 * BookCategory enum is used for declaring the details of book categories
 *
 */
public enum BookCategory {

	ADVENTURE, ACTION, THRILLER, FICTION, COMEDY, ROMANTIC
}
