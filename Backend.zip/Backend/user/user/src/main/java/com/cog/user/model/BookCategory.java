package com.cog.user.model;

public enum BookCategory {
	
	ADVENTURE, ACTION, THRILLER, FICTION, COMEDY, ROMANTIC

}
