package com.cog.user.model;
/**
 * 
 * @author sindhu
 *  ERole enum is used for declaring the role
 *
 */
public enum ERole {
	ROLE_READER, ROLE_AUTHOR
	
}
