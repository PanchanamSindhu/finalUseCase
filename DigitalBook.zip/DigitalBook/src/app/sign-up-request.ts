export class SignUpRequest {

    name!: String;
    userName!: String;
    emailId!: String;
    password!: String;
    role:string[]=[];
}
